import { EditorLayout } from "@/components/EditorLayout";

const Index = () => {
  return <EditorLayout />;
};

export default Index;
